from crewai import Task
from agents import make_planning_agent, make_math_agent

def make_tasks(person: dict):
    planning_agent = make_planning_agent()
    math_agent = make_math_agent()

    calculation_task = Task(
        description=(
            f"Perform a full retirement calculation for the following person:\n\n"
            f"  Name                   : {person['name']}\n"
            f"  Age                    : {person['age']}\n"
            f"  Current Monthly Income : £{person['current_monthly_income']}\n"
            f"  Current Monthly Savings: £{person['current_monthly_savings']}\n"
            f"  Target Monthly Income  : £{person['target_monthly_income']} (at age 60)\n\n"
            f"Use the Retirement Calculator tool with these exact values. "
            f"Present a clearly formatted mathematical summary including:\n"
            f"  - Years to retirement\n"
            f"  - Required retirement corpus\n"
            f"  - Projected corpus from current savings\n"
            f"  - Corpus gap (if any)\n"
            f"  - Required vs current monthly savings\n"
            f"  - Whether they are currently on track\n"
            f"  - Inflation-adjusted target income at retirement\n"
        ),
        expected_output=(
            "A detailed mathematical summary with all retirement figures clearly "
            "labelled, including whether the person is on track and the savings "
            "gap or surplus."
        ),
        agent=math_agent
    )

    planning_task = Task(
        description=(
            f"Using the mathematical summary from the retirement calculation, "
            f"develop a personalised retirement plan for {person['name']}, aged {person['age']}.\n\n"
            f"Their current monthly income is £{person['current_monthly_income']} "
            f"and they save £{person['current_monthly_savings']} per month.\n"
            f"Their target monthly income at retirement (age 60) is £{person['target_monthly_income']}.\n\n"
            f"Use the Investment Breakdown Calculator to suggest an asset allocation. "
            f"Your plan should include:\n"
            f"  1. Executive summary of their retirement readiness\n"
            f"  2. Recommended monthly savings target\n"
            f"  3. Investment allocation strategy (equity vs debt split)\n"
            f"  4. Specific investment instruments to consider\n"
            f"  5. Key milestones to hit (e.g. at age 40, 50, 55)\n"
            f"  6. Risks and assumptions\n"
            f"  7. Actionable next steps\n"
        ),
        expected_output=(
            "A comprehensive, easy-to-read retirement plan with clear sections, "
            "actionable recommendations, and an investment strategy tailored to "
            "the individual's age and income profile."
        ),
        agent=planning_agent,
        context=[calculation_task]  # planner sees the math output first
    )

    return [calculation_task, planning_task], planning_agent, math_agent