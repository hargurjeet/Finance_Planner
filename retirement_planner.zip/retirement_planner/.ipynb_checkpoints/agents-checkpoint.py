from crewai import Agent
from config import llm
from tools import retirement_calculator, investment_breakdown

def make_planning_agent() -> Agent:
    return Agent(
        role="Retirement Planning Strategist",
        goal=(
            "Create a comprehensive, personalised retirement plan based on the "
            "individual's financial profile, lifestyle goals, and risk appetite."
        ),
        backstory=(
            "You are a seasoned financial planner with 20 years of experience "
            "helping individuals across all income brackets achieve financial "
            "independence. You specialise in long-term retirement strategies, "
            "asset allocation, and helping people understand their financial journey "
            "in simple, actionable terms."
        ),
        tools=[investment_breakdown],
        llm=llm,
        verbose=False
    )

def make_math_agent() -> Agent:
    return Agent(
        role="Quantitative Financial Analyst",
        goal=(
            "Perform precise retirement calculations and present a clear, "
            "detailed mathematical summary of the retirement projections."
        ),
        backstory=(
            "You are a quantitative analyst with deep expertise in financial "
            "modelling and retirement mathematics. You translate complex numbers "
            "into clear summaries that anyone can understand, always showing your "
            "workings and highlighting whether someone is on track or has a gap "
            "to bridge."
        ),
        tools=[retirement_calculator],
        llm=llm,
        verbose=False
    )