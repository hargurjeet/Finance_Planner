from crewai import Crew, Process
from tasks import make_tasks

def get_user_inputs() -> dict:
    print("\n========================================")
    print("   🏦  Retirement Planner - powered by AI")
    print("========================================\n")
    return {
        "name"                   : input("Your name                          : ").strip(),
        "age"                    : int(input("Your current age                   : ")),
        "current_monthly_income" : float(input("Current monthly income (£)         : ")),
        "current_monthly_savings": float(input("Current monthly savings (£)        : ")),
        "target_monthly_income"  : float(input("Target monthly income at 60 (£)    : ")),
    }

def main():
    person = get_user_inputs()
    tasks, planning_agent, math_agent = make_tasks(person)

    crew = Crew(
        agents=[math_agent, planning_agent],
        tasks=tasks,
        process=Process.sequential,  # math runs first, then planning uses its output
        verbose=True
    )

    print("\n⏳ Running your retirement analysis...\n")
    result = crew.kickoff()

    print("\n========================================")
    print("         📋 YOUR RETIREMENT PLAN")
    print("========================================\n")
    print(result)

if __name__ == "__main__":
    main()