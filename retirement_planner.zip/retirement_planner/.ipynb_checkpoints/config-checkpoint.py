import os
from crewai import LLM

os.environ["REGION"]="eu-west-2"
os.environ["OS_DOMAIN_NAME"] = "lv1f4jvn3ihrgtk5bj7h.eu-west-2.aoss.amazonaws.com"
os.environ["BUCKET"] ="query-contract-767397757887"
os.environ["S3_URL_EXPIRY"] ="3600"
os.environ["DYNAMO_DB_TABLE"] ="query-contract-icm_master"
os.environ["UI_FRONTEND_URL"] ="https://icm.framework.dev.digital-ent-int.bt.com"
os.environ["HF_HOME"] ="/tmp/"
os.environ["ENDPOINT_NAME"]="mixtral-8x-7b-instruct-endpoint"
os.environ["ANTHROPIC_CLAUDE_3_SONNET_20240229_V1_0"]="arn:aws:bedrock:eu-west-2:767397757887:application-inference-profile/as5cyt2g5yy5"
os.environ["MISTRAL_MIXTRAL_8X7B_INSTRUCT_V0_1"]="arn:aws:bedrock:eu-west-2:767397757887:application-inference-profile/9o9mbrjwndfb"
os.environ["ANTHROPIC_CLAUDE_3_HAIKU_20240307_V1_0"]="arn:aws:bedrock:eu-west-2:767397757887:application-inference-profile/ybok7n104z1f"
os.environ["ANTHROPIC_CLAUDE_3_7_SONNET_20250219_V1_0"]="arn:aws:bedrock:eu-west-2:767397757887:application-inference-profile/39byv8qub7f5"

def make_bedrock_llm(
    model_env_var: str = "ANTHROPIC_CLAUDE_3_7_SONNET_20250219_V1_0",
    temperature: float = 0.3,
    top_p: float = 0.1,
    max_tokens: int = 2048,
    region: str = "eu-west-2"
) -> LLM:
    arn = os.environ.get(model_env_var)
    if not arn:
        raise ValueError(f"Environment variable '{model_env_var}' not set.")
    return LLM(
        model=f"bedrock/converse/{arn}",
        region_name=region,
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens
    )

llm = make_bedrock_llm()